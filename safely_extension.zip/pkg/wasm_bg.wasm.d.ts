/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const analyze_signals: (a: number, b: number) => [number, number];
export const build_activity_bars: (a: number, b: number) => [number, number];
export const build_signal_rows: (a: number, b: number) => [number, number];
export const risk_desc: (a: number, b: number) => [number, number];
export const risk_label: (a: number, b: number) => [number, number];
export const risk_level: (a: number) => [number, number];
export const status_icon: (a: number, b: number) => [number, number];
export const verification_badge: (a: number, b: number) => [number, number];
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
