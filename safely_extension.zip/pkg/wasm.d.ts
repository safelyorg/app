/* tslint:disable */
/* eslint-disable */

export function analyze_signals(signals_json: string): string;

export function build_activity_bars(activity: Uint8Array): string;

/**
 * Redesigned to match the Recommended Checks card style - separate
 * rounded cards with spacing between them (safely-check-card), instead
 * of a single bordered list with a colored left-border line per row.
 * The status word itself (Verified/Suspicious/Detected/etc.) is now
 * the only color differentiation, shown as colored text next to the
 * label rather than as a border color.
 */
export function build_signal_rows(signals_json: string): string;

export function risk_desc(desc: string): string;

export function risk_label(level: string): string;

export function risk_level(score: number): string;

export function status_icon(status: string): string;

export function verification_badge(status: string): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly analyze_signals: (a: number, b: number) => [number, number];
    readonly build_activity_bars: (a: number, b: number) => [number, number];
    readonly build_signal_rows: (a: number, b: number) => [number, number];
    readonly risk_desc: (a: number, b: number) => [number, number];
    readonly risk_label: (a: number, b: number) => [number, number];
    readonly risk_level: (a: number) => [number, number];
    readonly status_icon: (a: number, b: number) => [number, number];
    readonly verification_badge: (a: number, b: number) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
