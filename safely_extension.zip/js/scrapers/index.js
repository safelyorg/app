"use strict";
(function () {
    "use strict";
    let PROTECTED_DOMAINS = [];
    const DOMAINS_CACHE_KEY = "safely_protected_domains_cache";
    const DOMAINS_CACHE_TIMESTAMP_KEY = "safely_protected_domains_cached_at";
    const CACHE_LIFETIME_MS = 24 * 60 * 60 * 1000; // 24 hours
    async function loadProtectedDomains() {
        try {
            const cached = (await chrome.storage.local.get([
                DOMAINS_CACHE_KEY,
                DOMAINS_CACHE_TIMESTAMP_KEY,
            ]));
            const cachedAt = cached[DOMAINS_CACHE_TIMESTAMP_KEY] || 0;
            const isFresh = Date.now() - cachedAt < CACHE_LIFETIME_MS;
            if (isFresh && cached[DOMAINS_CACHE_KEY]) {
                PROTECTED_DOMAINS = cached[DOMAINS_CACHE_KEY];
                return;
            }
            const apiBase = window.__safelyAPI?.SITE_BASE || "http://localhost:3000";
            const response = await fetch(apiBase + "/api/v1/platform-domains");
            const data = await response.json();
            PROTECTED_DOMAINS = Object.entries(data).map(([name, domain]) => ({
                name,
                domain: domain,
            }));
            await chrome.storage.local.set({
                [DOMAINS_CACHE_KEY]: PROTECTED_DOMAINS,
                [DOMAINS_CACHE_TIMESTAMP_KEY]: Date.now(),
            });
        }
        catch (e) {
            console.error("Safely: failed to load protected domains list", e);
        }
    }
    function normalize(hostname) {
        return hostname
            .toLowerCase()
            .replace(/0/g, "o")
            .replace(/1/g, "l")
            .replace(/rn/g, "m")
            .replace(/vv/g, "w")
            .replace(/-/g, "");
    }
    function editDistance(a, b) {
        const m = a.length;
        const n = b.length;
        const dp = [];
        for (let i = 0; i <= m; i++)
            dp.push([i]);
        for (let j = 0; j <= n; j++)
            dp[0][j] = j;
        for (let i = 1; i <= m; i++) {
            for (let j = 1; j <= n; j++) {
                dp[i][j] =
                    a[i - 1] === b[j - 1]
                        ? dp[i - 1][j - 1]
                        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
            }
        }
        return dp[m][n];
    }
    function highlightDiff(a, b) {
        const m = a.length;
        const n = b.length;
        const dp = [];
        for (let i = 0; i <= m; i++) {
            dp.push([]);
            for (let j = 0; j <= n; j++) {
                if (i === 0)
                    dp[i][j] = j;
                else if (j === 0)
                    dp[i][j] = i;
                else if (a[i - 1] === b[j - 1])
                    dp[i][j] = dp[i - 1][j - 1];
                else
                    dp[i][j] = 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
            }
        }
        const aMarks = new Array(m).fill(false);
        const bMarks = new Array(n).fill(false);
        let i2 = m;
        let j2 = n;
        while (i2 > 0 || j2 > 0) {
            if (i2 > 0 && j2 > 0 && a[i2 - 1] === b[j2 - 1] && dp[i2][j2] === dp[i2 - 1][j2 - 1]) {
                i2--;
                j2--;
            }
            else if (i2 > 0 && j2 > 0 && dp[i2][j2] === dp[i2 - 1][j2 - 1] + 1) {
                aMarks[i2 - 1] = true;
                bMarks[j2 - 1] = true;
                i2--;
                j2--;
            }
            else if (i2 > 0 && dp[i2][j2] === dp[i2 - 1][j2] + 1) {
                aMarks[i2 - 1] = true;
                i2--;
            }
            else {
                bMarks[j2 - 1] = true;
                j2--;
            }
        }
        function build(str, marks) {
            let html = "";
            for (let k = 0; k < str.length; k++) {
                html += marks[k]
                    ? '<mark style="background:#ff5d5d33;color:#ff5d5d;font-weight:800;border-radius:3px;padding:0 2px;">' +
                        str[k] +
                        "</mark>"
                    : str[k];
            }
            return html;
        }
        return { currentHtml: build(a, aMarks), realHtml: build(b, bMarks) };
    }
    function isGenuineDomain(hostname, realDomain) {
        return hostname === realDomain || hostname.endsWith("." + realDomain);
    }
    function checkDomain() {
        const hostname = window.location.hostname;
        for (const entry of PROTECTED_DOMAINS) {
            if (isGenuineDomain(hostname, entry.domain)) {
                return {
                    status: "legitimate",
                    realName: entry.name,
                    realDomain: entry.domain,
                };
            }
            const homoglyphMatch = normalize(hostname) === normalize(entry.domain);
            const distance = editDistance(hostname, entry.domain);
            const closeEnough = distance > 0 && distance <= 2 && entry.domain.length > 5;
            if (homoglyphMatch || closeEnough) {
                const diffed = highlightDiff(hostname, entry.domain);
                return {
                    status: "suspicious",
                    realName: entry.name,
                    realDomain: entry.domain,
                    currentDomain: hostname,
                    reason: homoglyphMatch ? "lookalike-characters" : "similar-spelling",
                    currentDomainHtml: diffed.currentHtml,
                    realDomainHtml: diffed.realHtml,
                };
            }
        }
        return null;
    }
    const platformRegistry = [
        {
            name: "olx",
            matchesHostname: (hostname) => hostname.includes("olx.com"),
            requiresClientSideScraping: false,
            isListingUrl: (url) => url.includes("iid-"),
        },
        {
            name: "b2brazil",
            matchesHostname: (hostname) => hostname.includes("b2brazil.com"),
            requiresClientSideScraping: false,
            isListingUrl: (url) => url.includes("/hotsite/"),
        },
        {
            name: "alibaba",
            matchesHostname: (hostname) => hostname.includes("alibaba.com"),
            requiresClientSideScraping: false,
            isListingUrl: (url) => url.includes("/product-detail/"),
        },
        {
            name: "tradewheel",
            matchesHostname: (hostname) => hostname.includes("tradewheel.com"),
            requiresClientSideScraping: true,
            isListingUrl: (url) => url.includes("/p/"),
        },
        {
            name: "exporthub",
            matchesHostname: (hostname) => hostname.includes("exporthub.com"),
            requiresClientSideScraping: false,
            isListingUrl: (url) => url.includes("/product/"),
        },
        {
            name: "thomasnet",
            matchesHostname: (hostname) => hostname.includes("thomasnet.com"),
            requiresClientSideScraping: false,
            isListingUrl: (url) => url.includes("/company/") && url.includes("/profile"),
        },
    ];
    function detectPlatform() {
        const hostname = window.location.hostname;
        const match = platformRegistry.find((p) => p.matchesHostname(hostname));
        return match ? match.name : "unknown";
    }
    function requiresClientSideScraping(platform) {
        return platformRegistry.find((p) => p.name === platform)?.requiresClientSideScraping ?? true;
    }
    function isListingPage() {
        const url = window.location.href;
        const platform = detectPlatform();
        const config = platformRegistry.find((p) => p.name === platform);
        return config ? config.isListingUrl(url) : false;
    }
    window.__safelyScrapers = window.__safelyScrapers || {};
    window.__safelyScrapers.detectPlatform = detectPlatform;
    window.__safelyScrapers.loadProtectedDomains = loadProtectedDomains;
    window.__safelyScrapers.isListingPage = isListingPage;
    window.__safelyScrapers.requiresClientSideScraping = requiresClientSideScraping;
    window.__safelyScrapers.checkDomain = checkDomain;
    window.__safelyScrapers.normalize = normalize;
    window.__safelyScrapers.editDistance = editDistance;
    window.__safelyScrapers.highlightDiff = highlightDiff;
    window.__safelyScrapers.isGenuineDomain = isGenuineDomain;
    /// Finds the real company profile link on a TradeWheel listing
    /// page, then fetches that page in the background, using the
    /// visiting user's own, real browser session (their cookies are
    /// sent automatically by the browser, since this fetch runs on the
    /// tradewheel.com origin itself). Extracts the real website field
    /// if the fetched page shows one - which only happens for a
    /// genuinely logged-in visitor.
    async function fetchTradewheelWebsite() {
        const companyLink = document.querySelector(".comp-info a");
        if (!companyLink)
            return null;
        try {
            const response = await fetch(companyLink.href, { credentials: "include" });
            if (!response.ok)
                return null;
            const html = await response.text();
            const doc = new DOMParser().parseFromString(html, "text/html");
            const rows = doc.querySelectorAll(".contact_details table tr");
            for (const row of Array.from(rows)) {
                const text = row.textContent?.trim() || "";
                if (text.startsWith("Website:")) {
                    const value = text.replace("Website:", "").trim();
                    if (value && value.toLowerCase() !== "show") {
                        return value;
                    }
                    return null;
                }
            }
            return null;
        }
        catch (e) {
            console.error("Safely: failed to fetch TradeWheel company page", e);
            return null;
        }
    }
    window.__safelyScrapers.fetchTradewheelWebsite = fetchTradewheelWebsite;
})();
